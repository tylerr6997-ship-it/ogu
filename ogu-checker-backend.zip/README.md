# OGU Checker Backend

This is the backend for the OGU Checker website.

## What it does

`GET /api/check/roblox/:username`

Example:

`http://localhost:3000/api/check/roblox/builderman`

The backend asks Roblox's public Users API whether an account is returned for that username.

### Result meanings

- `taken` = Roblox returned an existing user.
- `not_found` = Roblox returned no existing user for that name.
- `invalid` = username format is invalid.
- `error` = the Roblox request failed.

**Important:** `not_found` is deliberately called "unconfirmed", not "available". A username can be unavailable for reasons that an existence lookup does not reveal.

## Run locally

Install Node.js 18+.

Then:

```bash
npm install
npm start
```

Open:

`http://localhost:3000`

## Connecting the HTML

Your frontend can call:

```js
fetch(`https://YOUR-BACKEND-DOMAIN/api/check/roblox/${encodeURIComponent(username)}`)
```

Do not put private API keys in GitHub Pages frontend code.

## Hosting

GitHub Pages can host the frontend, but it does not run a Node/Express server. Deploy this backend separately on a Node-compatible hosting service, then put that backend URL into your frontend.
